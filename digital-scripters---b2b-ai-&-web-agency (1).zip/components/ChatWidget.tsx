
import React, { useState, useRef, useEffect } from 'react';
import { chatService } from '../services/gemini';
import { storageService } from '../services/storage';

const ChatWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'model', text: string }[]>([
    { role: 'model', text: "Hello! 👋 I'm the Digital Scripters AI Assistant. How can I help you today?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input;
    setInput('');
    const newMessages = [...messages, { role: 'user' as const, text: userMsg }];
    setMessages(newMessages);
    setIsLoading(true);

    try {
      const history = newMessages.map(m => ({ 
        role: m.role, 
        parts: [{ text: m.text }] 
      }));
      
      const response = await chatService.sendMessage(userMsg, history.slice(0, -1));
      
      let aiText = response.text || "";

      if (response.functionCalls) {
        // We handle tool calls one by one
        // Note: For a more complex app, we'd need to send tool outputs back to Gemini
        // But here we can simulate a multi-turn tool interaction logic
        for (const fc of response.functionCalls) {
          if (fc.name === 'check_availability') {
            const isAvailable = storageService.isSlotAvailable((fc.args as any).datetime);
            const result = isAvailable ? "available" : "unavailable";
            
            // Re-query Gemini with the tool output to get a proper verbal response
            const toolHistory = [
               ...history,
               { role: 'model', parts: [{ functionCall: fc }] },
               { role: 'user', parts: [{ functionResponse: { name: fc.name, response: { result } } }] }
            ];
            const followUp = await chatService.sendMessage("", toolHistory);
            aiText = followUp.text || aiText;
          }

          if (fc.name === 'create_appointment') {
            const args = fc.args as any;
            const success = storageService.saveAppointment({
              name: args.name,
              email: args.email,
              phone: args.phone,
              service: args.service,
              requested_time: args.datetime,
              booking_status: 'confirmed'
            });
            
            if (!success) {
               aiText = "I'm sorry, that time was just taken. Could we try another time?";
            } else {
               console.log("CHAT-SYNC: Appointment Created for", args.datetime);
            }
          }

          if (fc.name === 'send_email') {
            const args = fc.args as any;
            console.log("CHAT-SYNC: Email Sent to", args.to);
          }
        }
      }

      setMessages(prev => [...prev, { role: 'model', text: aiText || "I'm here to assist. What else can I do for you?" }]);
      
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: "Apologies, something went wrong. Let's try again." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60]">
      {isOpen ? (
        <div className="w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col h-[500px] transition-all transform scale-100 origin-bottom-right">
          <div className="bg-blue-600 p-4 flex justify-between items-center text-white">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center font-bold">DS</div>
              <span className="font-semibold">AI Chat Assistant</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-blue-500 rounded p-1">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
          
          <div ref={scrollRef} className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed ${
                  m.role === 'user' 
                    ? 'bg-blue-600 text-white rounded-tr-none' 
                    : 'bg-white border border-slate-200 text-slate-700 rounded-tl-none shadow-sm'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white border border-slate-200 p-3 rounded-2xl rounded-tl-none animate-pulse text-slate-400 text-xs">
                  Thinking...
                </div>
              </div>
            )}
          </div>

          <div className="p-4 bg-white border-t border-slate-100 flex space-x-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Message Assistant..."
              className="flex-1 bg-slate-50 border-none rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-600 outline-none"
            />
            <button
              onClick={handleSend}
              disabled={isLoading}
              className="bg-blue-600 text-white p-2.5 rounded-xl hover:bg-blue-700 transition-all disabled:opacity-50"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-blue-600 text-white p-4 rounded-full shadow-2xl hover:bg-blue-700 transition-all hover:scale-110 flex items-center justify-center group"
        >
          <svg className="w-6 h-6 group-hover:rotate-12 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
          <span className="max-w-0 overflow-hidden whitespace-nowrap group-hover:max-w-xs transition-all duration-300 group-hover:ml-3 font-bold uppercase text-[10px] tracking-widest">Chat with AI</span>
        </button>
      )}
    </div>
  );
};

export default ChatWidget;
