
import React, { useState, useRef, useEffect } from 'react';
import { chatService } from '../services/gemini';
import { storageService } from '../services/storage';
import { LiveServerMessage, Modality, Blob } from '@google/genai';

// Audio Helpers
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

const VoiceWidget: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [status, setStatus] = useState<string>('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  
  const sessionRef = useRef<any>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const micStreamRef = useRef<MediaStream | null>(null);

  const stopConversation = async () => {
    if (sessionRef.current) {
      try { sessionRef.current.close(); } catch (e) {}
      sessionRef.current = null;
    }
    
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach(track => track.stop());
      micStreamRef.current = null;
    }

    const inCtx = inputAudioContextRef.current;
    if (inCtx && inCtx.state !== 'closed') {
      try { await inCtx.close(); } catch (e) {}
    }
    inputAudioContextRef.current = null;

    const outCtx = outputAudioContextRef.current;
    if (outCtx && outCtx.state !== 'closed') {
      try { await outCtx.close(); } catch (e) {}
    }
    outputAudioContextRef.current = null;

    sourcesRef.current.forEach(s => {
      try { s.stop(); } catch (e) {}
    });
    sourcesRef.current.clear();
    
    setIsActive(false);
    setIsSpeaking(false);
    setStatus('');
  };

  const startConversation = async () => {
    try {
      setIsActive(true);
      setStatus('Initializing Digital Scripters Voice Node...');

      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      inputAudioContextRef.current = inputAudioContext;
      outputAudioContextRef.current = outputAudioContext;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;

      const sessionPromise = chatService.getLiveConnection({
        onopen: () => {
          setStatus('Connected. Initializing Greeting...');
          const source = inputAudioContext.createMediaStreamSource(stream);
          const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
          scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
            const pcmBlob = createBlob(inputData);
            sessionPromise.then((session) => {
              if (session) {
                session.sendRealtimeInput({ media: pcmBlob });
              }
            });
          };
          source.connect(scriptProcessor);
          scriptProcessor.connect(inputAudioContext.destination);

          // Silent buffer to trigger greeting
          const silentBuffer = new Float32Array(320);
          sessionPromise.then(s => s.sendRealtimeInput({ 
            media: createBlob(silentBuffer)
          }));
        },
        onmessage: async (message: LiveServerMessage) => {
          if (message.toolCall) {
            for (const fc of message.toolCall.functionCalls) {
              if (fc.name === 'check_availability') {
                const isAvailable = storageService.isSlotAvailable((fc.args as any).datetime);
                const result = isAvailable ? "available" : "unavailable";
                sessionPromise.then(s => s.sendToolResponse({
                  functionResponses: { id: fc.id, name: fc.name, response: { result } }
                }));
              }
              if (fc.name === 'create_appointment') {
                const args = fc.args as any;
                const success = storageService.saveAppointment({
                  name: args.name,
                  email: args.email || 'not provided',
                  phone: args.phone,
                  service: args.service,
                  requested_time: args.datetime,
                  booking_status: 'confirmed'
                });
                
                sessionPromise.then(s => s.sendToolResponse({
                  functionResponses: { id: fc.id, name: fc.name, response: { result: success ? "ok" : "error_conflict" } }
                }));
              }
              if (fc.name === 'send_email') {
                const args = fc.args as any;
                console.log("VOICE-SYNC: Email Dispatch to", args.to);
                sessionPromise.then(s => s.sendToolResponse({
                  functionResponses: { id: fc.id, name: fc.name, response: { result: "ok" } }
                }));
              }
            }
          }

          const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (base64Audio && outputAudioContext.state !== 'closed') {
            setIsSpeaking(true);
            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
            const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioContext, 24000, 1);
            const source = outputAudioContext.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(outputAudioContext.destination);
            source.addEventListener('ended', () => {
              sourcesRef.current.delete(source);
              if (sourcesRef.current.size === 0) setIsSpeaking(false);
            });
            source.start(nextStartTimeRef.current);
            nextStartTimeRef.current += audioBuffer.duration;
            sourcesRef.current.add(source);
          }

          if (message.serverContent?.interrupted) {
            sourcesRef.current.forEach(s => {
              try { s.stop(); } catch (e) {}
            });
            sourcesRef.current.clear();
            nextStartTimeRef.current = 0;
            setIsSpeaking(false);
          }
        },
        onerror: (e: any) => {
          console.error("Voice Node Error:", e);
          setStatus('Network instability detected...');
        },
        onclose: () => {
          stopConversation();
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error("Voice Widget Error:", err);
      setStatus('Microphone access is required.');
      setTimeout(() => setIsActive(false), 3000);
    }
  };

  return (
    <div className="fixed bottom-6 left-6 z-[60] flex flex-col items-start pointer-events-none">
      <div className="pointer-events-auto">
        {isActive && (
          <div className="mb-4 bg-white/95 backdrop-blur-md border border-blue-200 p-5 rounded-[2.5rem] shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-[280px]">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex space-x-1 px-2 py-1 bg-blue-50 rounded-full">
                <div className={`w-1.5 h-3 bg-blue-500 rounded-full ${isActive && !isSpeaking ? 'animate-pulse' : ''}`}></div>
                <div className={`w-1.5 h-5 bg-blue-600 rounded-full ${isSpeaking ? 'animate-bounce' : ''}`}></div>
                <div className={`w-1.5 h-3 bg-blue-400 rounded-full ${isActive && !isSpeaking ? 'animate-pulse' : ''}`}></div>
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-blue-600">AI Voice Node</span>
            </div>
            <p className="text-sm font-bold text-slate-800 leading-relaxed mb-2">
              {isSpeaking ? 'Digital Scripters AI is speaking...' : 'Listening to your request...'}
            </p>
            <div className="h-0.5 w-full bg-slate-100 rounded-full overflow-hidden">
               <div className={`h-full bg-blue-600 transition-all duration-300 ${isSpeaking ? 'w-full' : 'w-0'}`}></div>
            </div>
          </div>
        )}
        <button
          onClick={isActive ? stopConversation : startConversation}
          className={`${
            isActive ? 'bg-red-500 scale-110 ring-8 ring-red-100' : 'bg-slate-950 hover:bg-blue-600'
          } text-white p-6 rounded-full shadow-[0_20px_50px_rgba(0,0,0,0.2)] transition-all duration-500 flex items-center justify-center relative group active:scale-95`}
        >
          {isActive ? (
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" /></svg>
          ) : (
            <svg className="w-8 h-8 group-hover:scale-110 transition-transform" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"/>
              <path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/>
            </svg>
          )}
          {isActive && (
            <div className="absolute -inset-2 rounded-full border-4 border-red-200 animate-ping opacity-20"></div>
          )}
        </button>
        {!isActive && (
          <div className="mt-4 ml-2 animate-in fade-in slide-in-from-left-2 duration-700 delay-500">
            <span className="px-3 py-1 bg-white border border-slate-100 rounded-full text-[9px] font-black text-slate-500 uppercase tracking-widest shadow-sm">AI Voice Assistant</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default VoiceWidget;
