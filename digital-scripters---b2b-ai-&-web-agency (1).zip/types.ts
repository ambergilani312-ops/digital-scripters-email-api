
export interface Appointment {
  id: string;
  name: string;
  email: string;
  phone: string;
  service: string;
  requested_time: string;
  booking_status: 'pending' | 'confirmed' | 'cancelled';
  confirmation_sent: boolean;
  createdAt: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'web' | 'ai' | 'automation';
}

export interface User {
  isLoggedIn: boolean;
}
