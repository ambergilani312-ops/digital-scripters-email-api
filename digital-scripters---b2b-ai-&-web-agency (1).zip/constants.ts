
import { Service } from './types';

export const SERVICES: Service[] = [
  {
    id: 'web-dev',
    title: 'High-Performance Web Design',
    description: 'Custom, SEO-optimized websites designed to convert UAE traffic into loyal customers. Perfect for salons and professional firms.',
    icon: '🌐',
    category: 'web'
  },
  {
    id: 'ai-voice',
    title: 'AI Voice Receptionist',
    description: 'A 24/7 intelligent voice agent that answers calls, books appointments, and integrates with your Google Calendar.',
    icon: '🎙️',
    category: 'ai'
  },
  {
    id: 'ai-chat',
    title: 'AI Chat Lead Qualification',
    description: 'Automated chat assistants that qualify leads and answer FAQs, ensuring no potential client is left waiting.',
    icon: '💬',
    category: 'ai'
  },
  {
    id: 'crm-automation',
    title: 'Business Automation',
    description: 'Workflow automations that connect your leads directly to your CRM, Gmail, and Google Calendar.',
    icon: '⚙️',
    category: 'automation'
  }
];

export const TESTIMONIALS = [
  {
    name: "Dr. Ahmed Mansour",
    role: "Lead Dentist, Dubai Dental",
    text: "Digital Scripters automated our booking system. The AI voice agent handles 40% of our calls now, freeing up our reception staff."
  },
  {
    name: "Sarah Jenkins",
    role: "Owner, Glow Salon & Spa",
    text: "The web development was top-notch. Our SEO rankings improved drastically within 3 months of the new launch."
  }
];

export const ADMIN_PASSWORD = 'amber321@';
