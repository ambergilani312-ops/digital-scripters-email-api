
import { Appointment } from '../types';

const STORAGE_KEY = 'digital_scripters_appointments';

export const storageService = {
  getAppointments: (): Appointment[] => {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  },

  isSlotAvailable: (requestedTime: string): boolean => {
    const appointments = storageService.getAppointments();
    
    // Parse the requested time
    const date = new Date(requestedTime);
    const hours = date.getHours();
    
    // BUSINESS HOURS ENFORCEMENT: 11 AM to 7 PM (19:00)
    // We check the hour component directly from the user's input string
    if (hours < 11 || hours >= 19) {
      return false;
    }

    const normalizedRequested = date.getTime();
    
    // Conflict check with existing bookings
    return !appointments.some(app => {
      const appTime = new Date(app.requested_time).getTime();
      // Assume appointments are 30 minutes long for conflict checking
      const thirtyMinutes = 30 * 60 * 1000;
      return Math.abs(appTime - normalizedRequested) < thirtyMinutes && app.booking_status !== 'cancelled';
    });
  },

  saveAppointment: (appointment: Omit<Appointment, 'id' | 'createdAt' | 'confirmation_sent'>): Appointment | null => {
    if (!storageService.isSlotAvailable(appointment.requested_time)) {
      return null;
    }

    const appointments = storageService.getAppointments();
    const newAppointment: Appointment = {
      ...appointment,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString(),
      confirmation_sent: true,
      booking_status: 'confirmed'
    };
    
    const updated = [newAppointment, ...appointments];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    
    window.dispatchEvent(new Event('appointmentsUpdated'));
    
    return newAppointment;
  },

  deleteAppointment: (id: string) => {
    const appointments = storageService.getAppointments();
    const updated = appointments.filter(a => a.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new Event('appointmentsUpdated'));
  },

  updateStatus: (id: string, status: Appointment['booking_status']) => {
    const appointments = storageService.getAppointments();
    const updated = appointments.map(a => a.id === id ? { ...a, booking_status: status } : a);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new Event('appointmentsUpdated'));
  }
};
