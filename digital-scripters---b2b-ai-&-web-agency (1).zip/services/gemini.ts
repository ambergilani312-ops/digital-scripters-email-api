
import { GoogleGenAI, Type, FunctionDeclaration, Modality } from "@google/genai";

export const checkAvailabilityTool: FunctionDeclaration = {
  name: 'check_availability',
  description: 'Checks if a specific date and time is available in the calendar and within business hours.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      datetime: { type: Type.STRING, description: 'The requested date and time in YYYY-MM-DD HH:MM format' }
    },
    required: ['datetime']
  }
};

export const createAppointmentTool: FunctionDeclaration = {
  name: 'create_appointment',
  description: 'Creates a business appointment in the system and Google Calendar',
  parameters: {
    type: Type.OBJECT,
    properties: {
      name: { type: Type.STRING, description: 'Full name of the client' },
      email: { type: Type.STRING, description: 'Email address of the client (optional)' },
      phone: { type: Type.STRING, description: 'Phone number of the client' },
      service: { type: Type.STRING, description: 'The service they want (Web development, AI chatbot, AI voice assistant)' },
      datetime: { type: Type.STRING, description: 'The requested date and time in YYYY-MM-DD HH:MM format' }
    },
    required: ['name', 'phone', 'service', 'datetime']
  }
};

export const sendEmailTool: FunctionDeclaration = {
  name: 'send_email',
  description: 'Sends a confirmation email via Gmail API',
  parameters: {
    type: Type.OBJECT,
    properties: {
      to: { type: Type.STRING },
      subject: { type: Type.STRING },
      message: { type: Type.STRING }
    },
    required: ['to', 'subject', 'message']
  }
};

const COMMON_RULES = `
- ONE QUESTION AT A TIME.
- BUSINESS HOURS: Strictly 11:00 AM to 7:00 PM Dubai Time (GST).
- MANDATORY: Before confirming any time, call 'check_availability'.
- If 'check_availability' returns "unavailable", inform the user that either the slot is taken or it is outside our 11 AM - 7 PM window.
- If 'check_availability' returns "available", proceed to confirm the details.
- Never hallucinate availability.
`;

export const CHAT_SYSTEM_INSTRUCTION = `You are the Digital Scripters AI Chat Assistant.
Greeting: "Hello! 👋 I'm the Digital Scripters AI Assistant. How can I help you today?"

BOOKING FLOW:
1. Greet and understand intent.
2. Ask for Name, Phone, Email, and Service (one by one).
3. Ask for Preferred Date/Time. Mention that we book between 11 AM and 7 PM Dubai Time.
4. CALL 'check_availability' for the provided time.
5. If available, repeat all details and ask "Is that correct?".
6. If correct, call 'create_appointment' and 'send_email'.

${COMMON_RULES}`;

export const VOICE_SYSTEM_INSTRUCTION = `You are the AI Voice Agent for Digital Scripters Agency. 

🔊 INSTANT GREETING:
"Hello! You’re speaking with the Digital Scripters AI Voice Assistant. How can I help you today?"

BOOKING FLOW:
1. Ask for Name, Phone, Email, and Service (one at a time).
2. Ask for Date and Time. Remind the caller we operate from 11 AM to 7 PM Dubai Time.
3. CALL 'check_availability' IMMEDIATELY once the user provides a time.
4. If the tool returns "unavailable", say: "I'm sorry, that time is either booked or outside our 11 AM to 7 PM window. Do you have another time in mind?"
5. If available, confirm: "You are {name}, your phone is {phone}, email is {email}, for {service} on {datetime}. Correct?"
6. Only call 'create_appointment' after user says "Yes" or "Correct".

${COMMON_RULES}
- Stay active. No technical jargon. No JSON aloud.`;

export const chatService = {
  async sendMessage(message: string, history: any[]) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-3-flash-preview';
    try {
      const response = await ai.models.generateContent({
        model,
        contents: [...history, { role: 'user', parts: [{ text: message }] }],
        config: {
          systemInstruction: CHAT_SYSTEM_INSTRUCTION,
          tools: [{ functionDeclarations: [checkAvailabilityTool, createAppointmentTool, sendEmailTool] }]
        }
      });
      return response;
    } catch (error) {
      console.error("Chat Error:", error);
      throw error;
    }
  },
  
  getLiveConnection(callbacks: any) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    return ai.live.connect({
      model: 'gemini-2.5-flash-native-audio-preview-12-2025',
      callbacks,
      config: {
        responseModalities: [Modality.AUDIO],
        systemInstruction: VOICE_SYSTEM_INSTRUCTION,
        tools: [{ functionDeclarations: [checkAvailabilityTool, createAppointmentTool, sendEmailTool] }],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } }
        }
      }
    });
  }
};
