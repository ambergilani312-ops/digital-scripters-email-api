
import React, { useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import ChatWidget from './components/ChatWidget';
import VoiceWidget from './components/VoiceWidget';
import Home from './pages/Home';
import Services from './pages/Services';
import About from './pages/About';
import Contact from './pages/Contact';
import AdminPanel from './components/AdminPanel';
import PrivacyPolicy from './pages/PrivacyPolicy';
import SecurityAudit from './pages/SecurityAudit';

// Component to ensure pages scroll to top on navigation
const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const App: React.FC = () => {
  return (
    <Router>
      <ScrollToTop />
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/services" element={<Services />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="/privacy" element={<PrivacyPolicy />} />
            <Route path="/security" element={<SecurityAudit />} />
          </Routes>
        </main>
        
        <footer className="bg-slate-950 text-white pt-24 pb-12 border-t border-slate-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-16">
              <div className="col-span-1 md:col-span-2">
                <div className="flex items-center gap-5 mb-8">
                  <div className="w-14 h-14 bg-slate-900 rounded-2xl flex items-center justify-center font-mono text-blue-400 font-bold border border-blue-500/30 code-glow shadow-2xl shadow-blue-500/5">
                    <span className="text-xl tracking-tighter">&lt;_</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-2xl font-black tracking-tighter text-white">Digital Scripters</span>
                    <span className="text-[10px] font-black text-blue-500 uppercase tracking-[0.3em] leading-tight">Global AI Engine</span>
                  </div>
                </div>
                <p className="text-slate-400 max-w-sm leading-relaxed mb-10 font-medium">
                  The world's leading architecture for autonomous business systems. We engineering high-performance web layers and intelligent voice receptionists that operate 24/7.
                </p>
                <div className="flex gap-4">
                  <a href="#" className="w-12 h-12 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-center hover:bg-blue-600 hover:border-blue-500 transition-all duration-300 group shadow-lg">
                    <svg className="w-6 h-6 text-slate-500 group-hover:text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.84 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>
                  </a>
                  <a href="#" className="w-12 h-12 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-center hover:bg-blue-600 hover:border-blue-500 transition-all duration-300 group shadow-lg">
                    <svg className="w-6 h-6 text-slate-500 group-hover:text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                  </a>
                  <a href="#" className="w-12 h-12 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-center hover:bg-blue-600 hover:border-blue-500 transition-all duration-300 group shadow-lg">
                    <svg className="w-6 h-6 text-slate-500 group-hover:text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                  </a>
                </div>
              </div>
              
              <div>
                <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-blue-500 mb-10">System Map</h4>
                <ul className="space-y-5 text-slate-500 font-bold text-sm">
                  <li><Link to="/services" className="hover:text-blue-400 transition-colors">Digital Solutions</Link></li>
                  <li><Link to="/about" className="hover:text-blue-400 transition-colors">Agency Stack</Link></li>
                  <li><Link to="/contact" className="hover:text-blue-400 transition-colors">Launch Demo</Link></li>
                  <li><Link to="/admin" className="text-slate-700 hover:text-white transition-colors">Admin Console</Link></li>
                </ul>
              </div>
              
              <div>
                <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-blue-500 mb-10">Global Ops</h4>
                <ul className="space-y-5 text-slate-500 font-bold text-sm">
                  <li className="flex items-center gap-3"><span className="text-slate-700 font-black">HQ</span> Business Bay, Dubai</li>
                  <li className="flex items-center gap-3"><span className="text-slate-700 font-black">NET</span> Worldwide Nodes</li>
                  <li className="text-blue-500 font-black tracking-tight"><a href="mailto:hello@digitalscripters.com" className="hover:underline">hello@digitalscripters.com</a></li>
                  <li className="text-xs opacity-40">AUTO-MONITORED 24/7</li>
                </ul>
              </div>
            </div>
            
            <div className="mt-20 pt-10 border-t border-slate-900 flex flex-col md:flex-row justify-between items-center gap-8">
              <p className="text-slate-600 text-[10px] font-black uppercase tracking-widest">
                &copy; {new Date().getFullYear()} Digital Scripters Global. Autonomous Ops Active.
              </p>
              <div className="flex gap-10 text-[10px] font-black uppercase tracking-[0.3em] text-slate-600">
                <Link to="/privacy" className="hover:text-blue-500 transition-colors">Privacy Node</Link>
                <Link to="/security" className="hover:text-blue-500 transition-colors">Security Hash</Link>
              </div>
            </div>
          </div>
        </footer>

        <ChatWidget />
        <VoiceWidget />
      </div>
    </Router>
  );
};

export default App;
