
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { SERVICES } from '../constants';

const Services: React.FC = () => {
  const navigate = useNavigate();

  const handleRequestDetails = (serviceTitle: string) => {
    // Navigate to contact and could potentially pass state for pre-selection
    navigate('/contact', { state: { service: serviceTitle } });
  };

  return (
    <div className="bg-white py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl lg:text-5xl font-extrabold text-slate-900 mb-4">Comprehensive AI & Web Services</h1>
          <p className="text-xl text-slate-600">Global solutions with local UAE expertise.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES.map((s) => (
            <div key={s.id} className="p-10 border border-slate-100 rounded-3xl bg-slate-50 hover:bg-white hover:shadow-2xl transition-all group">
              <div className="flex items-center gap-4 mb-6">
                <div className="text-5xl group-hover:scale-125 transition-transform">{s.icon}</div>
                <h3 className="text-2xl font-bold text-slate-800">{s.title}</h3>
              </div>
              <p className="text-slate-600 mb-8 leading-relaxed text-lg">{s.description}</p>
              
              <div className="space-y-3">
                <div className="flex items-center text-slate-700 font-medium">
                  <svg className="w-5 h-5 mr-3 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                  Global Service Standards
                </div>
                <div className="flex items-center text-slate-700 font-medium">
                  <svg className="w-5 h-5 mr-3 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                  Full Google API Integration
                </div>
                <div className="flex items-center text-slate-700 font-medium">
                  <svg className="w-5 h-5 mr-3 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                  24/7 Monitoring & Support
                </div>
              </div>

              <button 
                onClick={() => handleRequestDetails(s.title)}
                className="mt-10 w-full py-4 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-colors shadow-lg active:scale-95"
              >
                Request Details
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Services;
