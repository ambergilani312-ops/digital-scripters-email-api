
import React from 'react';
import { Link } from 'react-router-dom';
import { SERVICES, TESTIMONIALS } from '../constants';

const Home: React.FC = () => {
  return (
    <div className="space-y-32 pb-32">
      {/* Dynamic Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden pt-24 hero-mesh bg-white">
        {/* Background Decorative Elements */}
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-500 opacity-[0.03] blur-[100px] rounded-full -mr-64 -mt-64"></div>
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-teal-500 opacity-[0.03] blur-[100px] rounded-full -ml-64 -mb-64"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
            
            <div className="lg:col-span-7 reveal-up">
              <div className="inline-flex items-center gap-3 px-4 py-2 mb-8 text-[11px] font-extrabold tracking-[0.2em] text-blue-700 uppercase bg-blue-50 rounded-lg border border-blue-100 shadow-sm">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-600"></span>
                </span>
                Global Digital Architects
              </div>
              
              <h1 className="text-6xl md:text-8xl font-[900] text-slate-900 tracking-tighter mb-8 leading-[1.05]">
                Elite Web Dev <br/>
                <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-500 bg-clip-text text-transparent italic">
                  & Autonomous 
                </span> <br/>
                AI Systems.
              </h1>
              
              <p className="max-w-xl text-xl text-slate-600 mb-12 leading-relaxed font-medium">
                We architect performance-engineered web engines and deploy intelligent AI receptionists that manage your growth 24/7. High-conversion tech, global delivery, Dubai-born innovation.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-5">
                <Link
                  to="/contact"
                  className="group px-10 py-5 bg-slate-900 text-white font-black rounded-2xl shadow-2xl hover:bg-blue-600 transition-all flex items-center justify-center gap-3 hover:-translate-y-1 active:scale-95 text-lg"
                >
                  Book My Demo
                  <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
                </Link>
                <Link
                  to="/services"
                  className="px-10 py-5 bg-white text-slate-800 font-bold rounded-2xl border-2 border-slate-100 hover:border-blue-200 transition-all hover:bg-slate-50 text-lg text-center"
                >
                  Explore Capabilities
                </Link>
              </div>
            </div>

            <div className="lg:col-span-5 relative hidden lg:block">
              <div className="relative z-10 glass-dark p-2 rounded-[3rem] shadow-2xl float border border-slate-700">
                <div className="bg-slate-950 rounded-[2.8rem] overflow-hidden p-10 border border-slate-800">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="w-12 h-12 bg-blue-600/20 rounded-xl flex items-center justify-center text-blue-400 font-mono text-xl font-bold border border-blue-500/30">
                      &lt;_
                    </div>
                    <div>
                      <div className="text-white font-black text-sm uppercase tracking-widest">Digital Scripters v2.5</div>
                      <div className="text-blue-400 text-[10px] font-bold">LIVE SYSTEMS ANALYTICS</div>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <div className="h-1 bg-slate-800 rounded-full w-full overflow-hidden">
                       <div className="h-full bg-blue-500 w-3/4 animate-pulse"></div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-slate-900/50 p-4 rounded-2xl border border-slate-800">
                        <div className="text-slate-500 text-[10px] font-bold uppercase mb-1">Web Engine Load</div>
                        <div className="text-white font-black text-xl tracking-tight">0.4s</div>
                      </div>
                      <div className="bg-slate-900/50 p-4 rounded-2xl border border-slate-800">
                        <div className="text-slate-500 text-[10px] font-bold uppercase mb-1">Voice Accuracy</div>
                        <div className="text-white font-black text-xl tracking-tight">99.8%</div>
                      </div>
                    </div>
                    <div className="p-4 bg-blue-600/10 rounded-2xl border border-blue-500/20">
                      <div className="text-blue-400 font-mono text-xs mb-2">$ system run --full-automation</div>
                      <div className="text-white text-xs leading-relaxed font-mono">
                        > Syncing Web Lead qualification... OK<br/>
                        > Deploying AI Voice Node... OK<br/>
                        > Status: Global Revenue Optimized
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="absolute -top-12 -right-12 w-64 h-64 bg-blue-400/10 blur-[80px] rounded-full -z-10"></div>
              <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-teal-400/10 blur-[80px] rounded-full -z-10"></div>
            </div>

          </div>
        </div>
      </section>

      {/* Metrics Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 relative z-20">
        <div className="bg-white rounded-[2.5rem] p-10 shadow-xl border border-slate-100 grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="text-center group border-r border-slate-100 last:border-0">
            <div className="text-4xl font-black text-slate-900 mb-2 group-hover:text-blue-600 transition-colors tracking-tighter">500+</div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-widest">Websites Launched</div>
          </div>
          <div className="text-center group border-r border-slate-100 last:border-0">
            <div className="text-4xl font-black text-slate-900 mb-2 group-hover:text-blue-600 transition-colors tracking-tighter">24/7</div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-widest">AI Availability</div>
          </div>
          <div className="text-center group border-r border-slate-100 last:border-0">
            <div className="text-4xl font-black text-slate-900 mb-2 group-hover:text-blue-600 transition-colors tracking-tighter">45%</div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-widest">Growth Increase</div>
          </div>
          <div className="text-center group">
            <div className="text-4xl font-black text-slate-900 mb-2 group-hover:text-blue-600 transition-colors tracking-tighter">Global</div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-widest">Service Delivery</div>
          </div>
        </div>
      </section>

      {/* Pipeline Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-1 bg-gradient-to-r from-transparent via-slate-200 to-transparent hidden lg:block z-0"></div>
        <div className="text-center mb-20 relative z-10">
          <h2 className="text-4xl md:text-5xl font-black text-slate-900">The Growth Pipeline</h2>
          <p className="text-slate-500 mt-4 max-w-xl mx-auto">Precision engineering for businesses that refuse to settle.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
          {[
            { n: '01', t: 'Web Audit', d: 'Comprehensive analysis of your current digital conversion engine.' },
            { n: '02', t: 'AI Logic', d: 'Designing the custom persona and neural flows for your AI receptionist.' },
            { n: '03', t: 'Engineering', d: 'Simultaneous build of high-performance web and voice infrastructure.' },
            { n: '04', t: 'Full Sync', d: 'One-click deployment that connects your entire business to the world.' }
          ].map((step, idx) => (
            <div key={idx} className="group bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all duration-300">
              <div className="w-14 h-14 bg-slate-900 text-white rounded-2xl flex items-center justify-center text-xl font-black mb-6 group-hover:bg-blue-600 transition-colors">
                {step.n}
              </div>
              <h3 className="text-xl font-bold mb-3 text-slate-900">{step.t}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{step.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="bg-white rounded-[3rem] p-12 md:p-24 border border-slate-100 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-2 h-full bg-blue-600"></div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-8">Trusted by Global Visionaries</h2>
              <div className="space-y-12">
                {TESTIMONIALS.map((t, i) => (
                  <div key={i} className="relative pl-8">
                    <div className="absolute top-0 left-0 text-6xl text-blue-100 font-serif">“</div>
                    <p className="text-xl text-slate-700 italic relative z-10">
                      {t.text}
                    </p>
                    <div className="mt-6 flex items-center gap-4">
                      <div className="w-12 h-12 bg-gradient-to-tr from-blue-600 to-teal-400 rounded-full"></div>
                      <div>
                        <div className="font-black text-slate-900">{t.name}</div>
                        <div className="text-blue-600 font-bold text-xs uppercase tracking-widest">{t.role}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square bg-slate-900 rounded-[2.5rem] p-1 shadow-2xl overflow-hidden group">
                 <div className="h-full w-full bg-slate-800 flex items-center justify-center relative">
                    <div className="text-center p-8">
                       <span className="text-blue-400 font-mono text-6xl font-bold block mb-4">&lt;_</span>
                       <h4 className="text-white text-2xl font-black mb-2 text-glow">Digital Scripters</h4>
                       <p className="text-slate-400 text-sm tracking-[0.2em] font-bold uppercase">Web & AI Solutions</p>
                    </div>
                    <div className="absolute inset-0 bg-blue-500/10 group-hover:bg-blue-500/20 transition-all"></div>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
