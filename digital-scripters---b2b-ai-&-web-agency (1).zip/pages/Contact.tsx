
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { storageService } from '../services/storage';

const Contact: React.FC = () => {
  const location = useLocation();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: 'Web Development',
    time: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // If a service was passed via state (from Request Details button)
    if (location.state && (location.state as any).service) {
      setFormData(prev => ({ ...prev, service: (location.state as any).service }));
    }
  }, [location.state]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    const success = storageService.saveAppointment({
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      service: formData.service,
      requested_time: formData.time,
      booking_status: 'confirmed'
    });

    if (success) {
      setSubmitted(true);
    } else {
      setError("This slot is unavailable or outside our 11 AM - 7 PM business hours. Please choose another time.");
    }
  };

  if (submitted) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center p-6">
        <div className="text-center max-w-md bg-white p-12 rounded-[2rem] shadow-2xl border border-blue-100">
          <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6 text-4xl">✓</div>
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Booking Confirmed!</h2>
          <p className="text-slate-600 mb-8">
            Thank you {formData.name}. We've sent a confirmation email to {formData.email}. Our team will contact you shortly.
          </p>
          <button 
            onClick={() => setSubmitted(false)}
            className="text-blue-600 font-bold hover:underline"
          >
            Make another request
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 py-24 px-4">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16">
        <div>
          <h1 className="text-5xl font-extrabold text-slate-900 mb-6">Let's build your <br/><span className="text-blue-600">future together.</span></h1>
          <p className="text-xl text-slate-600 mb-10">
            Select a service and preferred time. Our global team will reach out within 2 hours to confirm details.
          </p>
          
          <div className="space-y-8">
            <div className="flex items-start gap-4">
              <div className="bg-white p-3 rounded-xl shadow-sm border border-slate-100">🌍</div>
              <div>
                <h4 className="font-bold">Global HQ</h4>
                <p className="text-slate-500">Business Bay, Dubai, UAE</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="bg-white p-3 rounded-xl shadow-sm border border-slate-100">✉️</div>
              <div>
                <h4 className="font-bold">Email Us</h4>
                <p className="text-slate-500">hello@digitalscripters.com</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="bg-white p-3 rounded-xl shadow-sm border border-slate-100">🕒</div>
              <div>
                <h4 className="font-bold">Booking Hours</h4>
                <p className="text-slate-500">11:00 AM – 07:00 PM (Dubai Time)</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-8 lg:p-12 rounded-[2.5rem] shadow-2xl shadow-blue-100 border border-slate-100">
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="p-4 bg-red-50 border border-red-100 text-red-600 text-sm font-bold rounded-xl animate-pulse">
                {error}
              </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Full Name</label>
                <input
                  required
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Phone Number</label>
                <input
                  required
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  placeholder="+x xxx xxx xxxx"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Email Address</label>
              <input
                required
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                placeholder="john@example.com"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Service</label>
                <select
                  value={formData.service}
                  onChange={(e) => setFormData({...formData, service: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                >
                  <option>Web Development</option>
                  <option>AI Voice Agent</option>
                  <option>AI Chatbot</option>
                  <option>Full Automation Package</option>
                  <option>High-Performance Web Design</option>
                  <option>AI Voice Receptionist</option>
                  <option>AI Chat Lead Qualification</option>
                  <option>Business Automation</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2 flex justify-between">
                  Preferred Date/Time
                  <span className="text-[10px] text-blue-500 uppercase tracking-tighter">11 AM - 7 PM</span>
                </label>
                <input
                  required
                  type="datetime-local"
                  value={formData.time}
                  onChange={(e) => setFormData({...formData, time: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                />
              </div>
            </div>
            <button className="w-full py-4 bg-blue-600 text-white font-extrabold rounded-xl shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all active:scale-95">
              Confirm Appointment
            </button>
          </form>
          <p className="mt-4 text-xs text-center text-slate-400">
            A confirmation email will be sent automatically. No payment required today.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Contact;
