
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="py-24">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-4xl lg:text-6xl font-extrabold text-slate-900 mb-8 text-center">AI Driven. <span className="text-blue-600 underline decoration-teal-400">Globally Scaling.</span></h1>
        <div className="prose prose-lg text-slate-600 mx-auto space-y-6">
          <p>
            Digital Scripters was founded with a singular mission: to bridge the gap between cutting-edge AI technology and growing businesses worldwide. While our roots are firmly planted in the innovation hub of the UAE, our reach is global.
          </p>
          <p>
            Our team consists of full-stack engineers and AI specialists who understand market nuances across continents. We build high-performance systems that scale, from bilingual voice agents to multi-region SEO strategies.
          </p>
          
          <div className="bg-slate-50 p-8 rounded-3xl border border-slate-100 my-12">
            <h3 className="text-2xl font-bold text-slate-800 mb-4">Our Core Values</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold text-blue-600">Reliability</h4>
                <p className="text-sm">In the B2B world, uptime is everything. Our systems are built on robust, enterprise-grade infrastructure.</p>
              </div>
              <div>
                <h4 className="font-bold text-blue-600">Innovation</h4>
                <p className="text-sm">We use the latest LLMs and Generative AI models to give your business a competitive edge.</p>
              </div>
              <div>
                <h4 className="font-bold text-blue-600">Simplicity</h4>
                <p className="text-sm">Technology should be invisible. We handle the complexity so you can focus on your clients.</p>
              </div>
              <div>
                <h4 className="font-bold text-blue-600">Global Perspective</h4>
                <p className="text-sm">Based in Dubai but serving clients globally, we bring international standards to every project.</p>
              </div>
            </div>
          </div>

          <p>
            Join the growing list of businesses that have transformed their digital presence and automated their front office with Digital Scripters.
          </p>
        </div>
      </div>
    </div>
  );
};

export default About;
