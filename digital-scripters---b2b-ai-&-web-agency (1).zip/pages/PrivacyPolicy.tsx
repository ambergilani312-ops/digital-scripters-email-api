
import React from 'react';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="py-32 bg-white">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-4xl lg:text-5xl font-black text-slate-900 mb-12">Privacy Policy</h1>
        <div className="prose prose-lg text-slate-600 space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-slate-800 mb-4">1. Data Collection</h2>
            <p>Digital Scripters Global collects data necessary for business automation and appointment scheduling. This includes names, emails, and phone numbers provided via our AI voice and chat agents.</p>
          </section>
          <section>
            <h2 className="text-2xl font-bold text-slate-800 mb-4">2. AI Training & Usage</h2>
            <p>Our AI models use anonymized interaction data to improve response accuracy. We never sell your personal or business data to third parties. All voice recordings are processed in secure environments and deleted after transaction confirmation unless specified otherwise.</p>
          </section>
          <section>
            <h2 className="text-2xl font-bold text-slate-800 mb-4">3. Security Standards</h2>
            <p>We leverage Google Cloud's enterprise-grade security protocols to store and process information. End-to-end encryption is applied to all data in transit between our AI agents and our storage servers.</p>
          </section>
          <section>
            <h2 className="text-2xl font-bold text-slate-800 mb-4">4. Global Compliance</h2>
            <p>Operating from Dubai, we adhere to the UAE Data Protection Laws while maintaining GDPR standards for our international clients. You have the right to request data deletion at any time by contacting hello@digitalscripters.com.</p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
