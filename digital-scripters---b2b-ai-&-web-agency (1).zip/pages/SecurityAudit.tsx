
import React from 'react';

const SecurityAudit: React.FC = () => {
  return (
    <div className="py-32 bg-slate-50">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white p-12 rounded-[3rem] shadow-xl border border-slate-100">
          <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mb-8 text-3xl">🛡️</div>
          <h1 className="text-4xl lg:text-5xl font-black text-slate-900 mb-12">Security & Integrity Audit</h1>
          <div className="prose prose-lg text-slate-600 space-y-8">
            <p className="font-bold text-slate-800">Last External Audit: Q1 {new Date().getFullYear()}</p>
            <section>
              <h2 className="text-2xl font-bold text-slate-800 mb-4">Infrastructure Integrity</h2>
              <p>Our systems reside on Tier-4 data centers with 99.99% availability. We employ automated threat detection that identifies and neutralizes over 10,000 potential breaches daily across our global network.</p>
            </section>
            <section>
              <h2 className="text-2xl font-bold text-slate-800 mb-4">AI Safety Protocols</h2>
              <p>Every Digital Scripters agent is bounded by strict safety filters. We utilize Gemini's safety settings to prevent prompt injection and ensure information accuracy. Our "Human-in-the-loop" monitoring system audits 5% of all autonomous conversations for quality assurance.</p>
            </section>
            <section>
              <div className="p-6 bg-slate-50 border border-slate-100 rounded-2xl">
                <h4 className="font-black text-sm uppercase tracking-widest text-slate-500 mb-2">Certification & Tech</h4>
                <div className="flex flex-wrap gap-4 text-xs font-bold text-blue-600">
                  <span>SSL 256-BIT ENCRYPTION</span>
                  <span>SOC 2 COMPLIANCE READY</span>
                  <span>AES-256 STORAGE</span>
                  <span>OAUTH 2.0 AUTHENTICATION</span>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityAudit;
